const API_TOKEN = "isi_token_anda_di_sini"; // api token do lu
module.exports = API_TOKEN;
