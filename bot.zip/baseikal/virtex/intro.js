const intro = "ALWAYS ZIYO🔥0ཻུ۪۪ꦽꦼ̷⸙‹•══════════♡᭄│----- *「 Kartu Intro 🎗️」* ------│ *Nama    : Botz v24 by ziyoo*│ *Umur     : 15 TAHUN* -----------------│ *Hobby   : Main game* ---------│ *Kelas     : Di DO* -------------------│ *Asal       : Bandung* -------------│ *Status    : private* ---------------╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙"
module.exports = {intro}

